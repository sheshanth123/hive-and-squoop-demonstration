#!/bin/bash
# Starts everything in the right order. Runs every time the container starts.
set -e

# 1. Format HDFS, but only the very first time
if [ ! -d /data/hdfs/namenode/current ]; then
  echo ">> First start: formatting the NameNode"
  hdfs namenode -format -force -nonInteractive
fi

# 2. HDFS and YARN daemons
echo ">> Starting HDFS and YARN"
hadoop-daemon.sh start namenode
hadoop-daemon.sh start datanode
yarn-daemon.sh start resourcemanager
yarn-daemon.sh start nodemanager

# 3. Wait until the NameNode answers and leaves safe mode
until hdfs dfsadmin -safemode get >/dev/null 2>&1; do sleep 2; done
hdfs dfsadmin -safemode wait

# 4. Folders Hive and Sqoop expect
hdfs dfs -mkdir -p /tmp /user/hive/warehouse /user/root /data
hdfs dfs -chmod -R 777 /tmp
hdfs dfs -chmod g+w /user/hive/warehouse

# 5. Create the metastore tables in MySQL (first time only)
if ! schematool -dbType mysql -info >/dev/null 2>&1; then
  echo ">> Initialising the Hive metastore schema in MySQL"
  schematool -dbType mysql -initSchema
fi

# 6. Hive Metastore, then HiveServer2
echo ">> Starting Hive Metastore"
nohup hive --service metastore > /var/log/hive-metastore.log 2>&1 &
until (echo > /dev/tcp/localhost/9083) 2>/dev/null; do sleep 2; done

echo ">> Starting HiveServer2 (takes a minute)"
nohup hive --service hiveserver2 > /var/log/hiveserver2.log 2>&1 &

echo ">> Lab is up. Open a shell with:  docker exec -it lab-hadoop bash"
exec tail -F /var/log/hive-metastore.log /var/log/hiveserver2.log
