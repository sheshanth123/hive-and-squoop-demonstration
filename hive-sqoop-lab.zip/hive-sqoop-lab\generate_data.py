"""
Generates the three datasets used in the Hive + Sqoop lab.
Plain Python, no external packages.  Same seed = same files every time.

    python3 generate_data.py
"""
import csv, os, random, datetime

random.seed(42)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------- departments
departments = [
    (1, "Engineering", "Bengaluru", 3500),
    (2, "Sales",       "Mumbai",    2200),
    (3, "Support",     "Chennai",   1500),
    (4, "Marketing",   "Delhi",     1200),
    (5, "Finance",     "Pune",       900),
    (6, "HR",          "Hyderabad",  700),
]
with open(os.path.join(OUT, "departments.csv"), "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["dept_id", "dept_name", "location", "annual_budget_lakhs"])
    w.writerows(departments)

# ------------------------------------------------------------------ employees
# role -> (min, max) monthly income in INR
roles = {
    "Engineering": {"Software Engineer": (45000, 90000), "Senior Engineer": (90000, 160000),
                    "Data Engineer": (60000, 120000), "QA Engineer": (35000, 75000),
                    "Engineering Manager": (150000, 250000)},
    "Sales":       {"Sales Executive": (25000, 55000), "Account Manager": (50000, 95000),
                    "Business Development": (35000, 80000), "Sales Manager": (90000, 170000)},
    "Support":     {"Support Associate": (20000, 40000), "Support Lead": (40000, 75000),
                    "Customer Success Manager": (60000, 110000)},
    "Marketing":   {"Marketing Executive": (28000, 60000), "Content Strategist": (40000, 80000),
                    "Marketing Manager": (95000, 160000)},
    "Finance":     {"Accountant": (30000, 60000), "Financial Analyst": (50000, 100000),
                    "Finance Manager": (100000, 180000)},
    "HR":          {"Recruiter": (28000, 55000), "HR Executive": (30000, 60000),
                    "HR Manager": (90000, 150000)},
}
dept_names   = ["Engineering", "Sales", "Support", "Marketing", "Finance", "HR"]
dept_weights = [35, 20, 18, 10, 9, 8]
cities       = ["Bengaluru", "Mumbai", "Chennai", "Delhi", "Pune", "Hyderabad"]
educations   = ["High School", "Bachelors", "Masters", "PhD"]
edu_weights  = [8, 57, 31, 4]

ref_date = datetime.date(2025, 1, 1)
start    = datetime.date(2012, 1, 1)
span     = (ref_date - start).days

rows = []
for emp_id in range(1, 10001):
    dept  = random.choices(dept_names, dept_weights)[0]
    role  = random.choice(list(roles[dept]))
    lo, hi = roles[dept][role]
    income = round(random.randint(lo, hi), -2)
    hired  = start + datetime.timedelta(days=random.randint(0, span - 1))
    years  = (ref_date - hired).days // 365
    age    = max(21, min(60, int(random.gauss(33, 7)) + min(years, 5)))
    sat    = random.choices([1, 2, 3, 4], [12, 20, 38, 30])[0]
    ot     = "Yes" if random.random() < 0.28 else "No"

    p = 0.08
    if ot == "Yes":          p += 0.14
    if sat <= 2:             p += 0.08
    if income < 40000:       p += 0.05
    if dept == "Sales":      p += 0.05
    if dept == "Support":    p += 0.04
    if years < 2:            p += 0.05
    attr = "Yes" if random.random() < p else "No"

    rows.append([emp_id, age, random.choice(["Male", "Female"]), dept, role,
                 random.choices(educations, edu_weights)[0],
                 random.choices(cities, [30, 18, 14, 14, 12, 12])[0],
                 hired.isoformat(), years, income, sat, ot, attr])

with open(os.path.join(OUT, "employees.csv"), "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["employee_id", "age", "gender", "department", "job_role", "education",
                "city", "hire_date", "years_at_company", "monthly_income",
                "job_satisfaction", "overtime", "attrition"])
    w.writerows(rows)

# ------------------------------------------------------------------- web logs
urls = ["/home", "/login", "/products", "/products/item", "/cart", "/checkout",
        "/api/orders", "/api/search", "/about", "/contact"]
url_w = [25, 10, 20, 15, 8, 5, 6, 7, 2, 2]
methods = ["GET", "POST", "PUT"]
statuses = [200, 301, 304, 403, 404, 500]
status_w = [80, 3, 5, 3, 6, 3]

day0 = datetime.date(2025, 1, 1)
with open(os.path.join(OUT, "web_logs.csv"), "w", newline="") as f:
    w = csv.writer(f, lineterminator="\n")
    w.writerow(["log_id", "ip_address", "log_date", "log_time", "method", "url",
                "status_code", "bytes_sent", "response_ms"])
    for i in range(1, 5001):
        d = day0 + datetime.timedelta(days=random.randint(0, 6))
        t = "%02d:%02d:%02d" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59))
        ip = "%d.%d.%d.%d" % (random.choice([49, 103, 117, 152, 182]), random.randint(0, 255),
                              random.randint(0, 255), random.randint(1, 254))
        status = random.choices(statuses, status_w)[0]
        sent = 0 if status in (301, 304) else int(random.lognormvariate(7.5, 0.8))
        resp = int(random.lognormvariate(4.6, 0.7)) + (800 if status == 500 else 0)
        w.writerow([i, ip, d.isoformat(), t, random.choices(methods, [85, 12, 3])[0],
                    random.choices(urls, url_w)[0], status, sent, resp])

print("Done. Files written to", OUT)
