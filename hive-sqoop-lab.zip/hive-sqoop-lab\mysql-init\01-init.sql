-- Runs once, the first time the MySQL container starts with an empty data volume.

-- Hive metastore database (latin1 avoids "key too long" errors in Hive's schema)
CREATE DATABASE metastore CHARACTER SET latin1;
CREATE USER 'hive'@'%' IDENTIFIED WITH mysql_native_password BY 'hivepass';
GRANT ALL PRIVILEGES ON metastore.* TO 'hive'@'%';

-- Business database that Sqoop will read from and write to
CREATE DATABASE company;
CREATE USER 'sqoop_user'@'%' IDENTIFIED WITH mysql_native_password BY 'sqoop_pass';
GRANT ALL PRIVILEGES ON company.* TO 'sqoop_user'@'%';

USE company;

CREATE TABLE departments (
  dept_id             INT PRIMARY KEY,
  dept_name           VARCHAR(50) NOT NULL,
  location            VARCHAR(50),
  annual_budget_lakhs INT
);

CREATE TABLE employees (
  employee_id      INT PRIMARY KEY,
  age              INT,
  gender           VARCHAR(10),
  department       VARCHAR(50),
  job_role         VARCHAR(60),
  education        VARCHAR(30),
  city             VARCHAR(50),
  hire_date        DATE,
  years_at_company INT,
  monthly_income   INT,
  job_satisfaction INT,
  overtime         VARCHAR(3),
  attrition        VARCHAR(3)
);

-- Empty on purpose: this is where `sqoop export` will write results
CREATE TABLE attrition_summary (
  department      VARCHAR(50) PRIMARY KEY,
  total_employees INT,
  left_count      INT,
  attrition_rate  DECIMAL(5,2)
);

LOAD DATA INFILE '/var/lib/mysql-files/departments.csv'
  INTO TABLE departments
  FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;

LOAD DATA INFILE '/var/lib/mysql-files/employees.csv'
  INTO TABLE employees
  FIELDS TERMINATED BY ',' LINES TERMINATED BY '\n' IGNORE 1 LINES;

FLUSH PRIVILEGES;
